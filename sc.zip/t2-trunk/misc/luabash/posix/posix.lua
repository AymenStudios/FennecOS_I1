-- posix.lua
-- support code for posix library

require"lposix"
